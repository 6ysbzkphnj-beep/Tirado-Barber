# Tirado Barber — web de reservas

## Qué incluye
- Web móvil y ordenador.
- Reserva por servicio: Degradado normal / Tinte.
- Degradado normal: 6 €. Tinte: 45 €.
- Duración: corte 45 min; tinte 120 min.
- Selección de día y horas disponibles.
- Confirmación automática.
- Bloqueo de horas ya reservadas.
- Dirección NO visible públicamente: se devuelve después de confirmar la cita.
- Instagram @tirado_barber.
- Backend gratuito con Google Apps Script + Google Calendar.

## Falta configurar
Como todavía no se han indicado el precio de cada servicio, el horario exacto del fin de semana, la dirección y el calendario, están como campos de configuración.

### Backend
En `apps_script.gs`:
- CALENDAR_ID
- ADDRESS
- WEEKEND_START
- WEEKEND_END

### Web
En `index.html`:
- API_URL

También puedes cambiar los textos "Precio a configurar" por los precios reales.

## Publicación gratis
Puedes subir `index.html` a GitHub Pages, Netlify o Vercel.
El backend se publica como Google Apps Script.

## Seguridad
La dirección real solo debe estar en Apps Script, no en el HTML público.
