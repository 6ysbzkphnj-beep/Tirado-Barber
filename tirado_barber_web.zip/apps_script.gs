/*
TIRADO BARBER — BACKEND GRATUITO CON GOOGLE APPS SCRIPT + GOOGLE CALENDAR

1) Crea un Google Calendar para las citas.
2) Crea un proyecto en script.google.com.
3) Pega este código.
4) Cambia CALENDAR_ID y ADDRESS.
5) Ajusta WEEKEND_START y WEEKEND_END.
6) Implementa como aplicación web:
   - Ejecutar como: tú
   - Quién tiene acceso: cualquiera
7) Copia la URL /exec y pégala en index.html en API_URL.

IMPORTANTE: no publiques este archivo con la dirección real en GitHub.
La dirección se guarda aquí y solo se devuelve después de una reserva confirmada.
*/

const CALENDAR_ID = "PEGA_AQUI_EL_ID_DEL_CALENDARIO";
const ADDRESS = "PEGA_AQUI_LA_DIRECCION_PRIVADA";

const WEEKDAY_MORNING_START = 10 * 60;
const WEEKDAY_MORNING_END = 13 * 60;
const WEEKDAY_AFTERNOON_START = 16 * 60;
const WEEKDAY_AFTERNOON_END = 19 * 60;
const WEEKEND_START = 10 * 60;
const WEEKEND_END = 13 * 60;
const CUT_DURATION = 45;
const DYE_DURATION = 120;

function doGet(e) {
  try {
    if (e.parameter.action === "slots") {
      return json({slots:getSlots(e.parameter.date)});
    }
    return json({ok:true});
  } catch(err) {
    return json({ok:false,error:String(err)});
  }
}

function doPost(e) {
  try {
    if (e.parameter.action !== "book") return json({ok:false,error:"Solicitud no válida."});
    const service=clean(e.parameter.service,60);
    const date=e.parameter.date;
    const time=e.parameter.time;
    const name=clean(e.parameter.name,60);
    const phone=clean(e.parameter.phone,20);

    if (!service || !date || !time || !name || !phone) throw new Error("Rellena todos los campos.");
    if (!["Degradado normal","Tinte"].includes(service)) throw new Error("Servicio no válido.");

    const start=parseDateTime(date,time);
    const duration=(service==="Tinte") ? DYE_DURATION : CUT_DURATION;
    const end=new Date(start.getTime()+duration*60000);
    const cal=CalendarApp.getCalendarById(CALENDAR_ID);
    if (!cal) throw new Error("No se encontró el calendario.");

    const day=start.getDay();
    const mins=start.getHours()*60+start.getMinutes();
    const windows=(day===6) ? [[WEEKEND_START,WEEKEND_END]]
      : (day>=1 && day<=5) ? [[WEEKDAY_MORNING_START,WEEKDAY_MORNING_END],
                               [WEEKDAY_AFTERNOON_START,WEEKDAY_AFTERNOON_END]] : [];
    if (!windows.some(w=>mins>=w[0] && mins+duration<=w[1]))
      throw new Error("Esa hora no permite completar el servicio.");

    // Bloqueo para evitar dos reservas simultáneas.
    const lock=LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      if (cal.getEvents(start,end).length) throw new Error("Esa hora acaba de ser ocupada. Elige otra.");
      cal.createEvent(`${service} — ${name}`,start,end,{
        description:`Cliente: ${name}\nTeléfono: ${phone}\nServicio: ${service}`
      });
    } finally { lock.releaseLock(); }

    return json({ok:true,service,date,time,address:ADDRESS});
  } catch(err) {
    return json({ok:false,error:String(err.message||err)});
  }
}

function getSlots(dateStr) {
  const d=new Date(dateStr+"T00:00:00");
  const day=d.getDay();
  if (day===0) return [];
  const windows=(day===6)
    ? [[WEEKEND_START,WEEKEND_END]]
    : [[WEEKDAY_MORNING_START,WEEKDAY_MORNING_END],
       [WEEKDAY_AFTERNOON_START,WEEKDAY_AFTERNOON_END]];
  const cal=CalendarApp.getCalendarById(CALENDAR_ID);
  const slots=[];
  for (const win of windows) {
    for(let mins=win[0]; mins<win[1]; mins+=15){
      const h=Math.floor(mins/60), m=mins%60;
      const start=new Date(d); start.setHours(h,m,0,0);
      const end=new Date(start.getTime()+15*60000);
      if(cal.getEvents(start,end).length===0)
        slots.push(Utilities.formatString("%02d:%02d",h,m));
    }
  }
  return slots;
}

function parseDateTime(dateStr,timeStr){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(dateStr) || !/^\d{2}:\d{2}$/.test(timeStr))
    throw new Error("Fecha u hora no válida.");
  const d=new Date(dateStr+"T"+timeStr+":00");
  if(isNaN(d.getTime())) throw new Error("Fecha u hora no válida.");
  return d;
}
function clean(v,max){
  return String(v||"").trim().replace(/[<>]/g,"").slice(0,max);
}
function json(o){
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
